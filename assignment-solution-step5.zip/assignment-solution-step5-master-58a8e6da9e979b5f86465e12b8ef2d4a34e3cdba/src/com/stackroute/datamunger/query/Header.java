package com.stackroute.datamunger.query;

import java.util.HashMap;

//header class containing a Collection containing the headers
public class Header extends HashMap<String, Integer> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2411339338180694480L;
	/*private String[] headers;

	public void setHeaders(String[] headers) {
		this.headers = headers;
	}

	public String[] getHeaders() {
		return headers;
	}*/
}