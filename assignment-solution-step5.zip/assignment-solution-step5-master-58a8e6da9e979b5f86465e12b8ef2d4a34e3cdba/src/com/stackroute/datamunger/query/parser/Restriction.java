package com.stackroute.datamunger.query.parser;

public class Restriction {

	private String propertyName, propertyValue, condition;

	public Restriction() {
	}

	@Override
	public String toString() {
		return propertyName + " " +condition+" "+ propertyValue;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}
}