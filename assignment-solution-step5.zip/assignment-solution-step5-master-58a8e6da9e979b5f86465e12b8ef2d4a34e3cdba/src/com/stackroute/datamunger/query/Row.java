package com.stackroute.datamunger.query;

import java.util.HashMap;

//contains the row object as ColumnName/Value 
public class Row extends HashMap<String, String>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7622327561999998271L;
	
}
