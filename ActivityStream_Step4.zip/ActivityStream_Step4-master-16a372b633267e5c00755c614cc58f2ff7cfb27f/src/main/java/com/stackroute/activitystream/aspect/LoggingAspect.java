package com.stackroute.activitystream.aspect;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/*
 * Code review comments: Why are you using S.O.P statements? You should use log.
 */

/*
 * Code review comments: As you have already created a bean in application context, @component is not required
 */
//@Component
@Aspect
public class LoggingAspect {
	/*
	 * Code review comments: Unnecessary code
	 */
	/*
	 * public LoggingAspect() {
	 * System.out.println("I m in LoggingAspect constructor"); }
	 */

	static Logger logger = Logger.getLogger(LoggingAspect.class);

	public LoggingAspect() {
		System.out.println("I m in LoggingAspect constructor");
		// PropertiesConfigurator is used to configure logger from properties file
		// PropertyConfigurator.configure("WEB-INF/resources/log4j.properties");
		// DOMConfigurator is used to configure logger from xml configuration file
		DOMConfigurator.configure("resources/log4j-config.xml");
		// Log in console in and log file
		logger.info("Log4j appender configuration is successful !!");
	}

	@Pointcut("within(@com.stackroute.activitystream.controller.UserAuthController)")
	public void controller() {
	}

	@Before("execution(public * authenticateUser(..))")
	public void loggingAdvice() {
		// System.out.println("login method called");
		logger.debug("..............++++++++++");
	}

	@After("execution(public * authenticateUser(..))")
	public void loggingAdvice2() {
		logger.info("after methods calling in UserAuthController");
	}
}