package com.stackroute.activitystream.config;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.stackroute.activitystream.model.Message;

@SuppressWarnings("deprecation")
public class HibernateUtil {
	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		Configuration config = new Configuration();
		try {
			config.configure("hibernate.cfg.xml");
			sessionFactory = config.buildSessionFactory();
			return sessionFactory;
		} catch (Exception exception) {
			exception.printStackTrace();
			return null;
		}
	}

	/*
	 * build the sessionFactory object based on the parameters from
	 * hibernate.cfg.xml file. Also, handle exception if the session factory
	 * object can't be created
	 */
	public boolean insertMessages(Message message) {
		this.sessionFactory = getSessionFactory();
		if (sessionFactory != null) {
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			try {

				message.setPostedDate();
				session.save(message);
			} catch (HibernateException e) {
				e.printStackTrace();
			}
			transaction.commit();
			return true;
		} else {
			return false;
		}
	}

	public List<Message> getAllMessages() {
		List<Message> messages = null;
		this.sessionFactory = getSessionFactory();
		if (sessionFactory != null) {
			Session session = sessionFactory.openSession();
			Transaction transaction = session.beginTransaction();
			try {
				Query<Message> query = session.createQuery("from Message");
				messages = query.list();
			} catch (HibernateException e) {
				e.printStackTrace();
			}
			transaction.commit();
			return messages;
		} else {
			return null;
		}
	}
}