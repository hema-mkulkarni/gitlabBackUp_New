package com.niit.dao;

import java.util.List;

import com.niit.model.Employee;

public interface EmployeeDao {
	List<Employee> getAllEmployees();

	boolean addEmployee(Employee employee);

	boolean updateEmployee(Employee employee);

	boolean deleteEmployee(Employee employee);
}
