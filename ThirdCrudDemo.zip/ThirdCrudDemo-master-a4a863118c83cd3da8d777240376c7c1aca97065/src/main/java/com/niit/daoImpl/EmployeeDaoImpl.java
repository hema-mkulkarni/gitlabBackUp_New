package com.niit.daoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.dao.EmployeeDao;
import com.niit.model.Employee;

@Repository(value = "employeeDAO")
@Transactional
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	SessionFactory sessionFactory;

	public EmployeeDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Employee> getAllEmployees() {
		Session session = null;
		session = sessionFactory.openSession();
		System.out.println("In getAllEmployees()");
		Query query = session.createQuery("from Employee order by empName");
		List<Employee> employees = query.list();
		session.close();
		return employees;
	}

	@Override
	public boolean addEmployee(Employee employee) {
		Session session = null;
		session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		return true;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		return false;
	}

	@Override
	public boolean deleteEmployee(Employee employee) {
		return false;
	}
}