package com.stackroute.datamunger;

import java.util.Scanner;

public class DataMunger {

	public static void main(String[] args) {


		/* read a sentence from the user */

		/*
		 * call getWordCount() method which should return no. of words present
		 * in the string and display the same
		 */

	}


	/*
	 * This method is used to calculate the no. of words present in the given
	 * string. Please note that in a sentence, words are split by space. Please change the method return 
	 * type to int
	 */
	public Object getWordCount(String string) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
