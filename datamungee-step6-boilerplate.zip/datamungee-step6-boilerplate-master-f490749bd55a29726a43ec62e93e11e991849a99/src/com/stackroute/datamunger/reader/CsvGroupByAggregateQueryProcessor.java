package com.stackroute.datamunger.reader;

import java.util.HashMap;

import com.stackroute.datamunger.query.parser.QueryParameter;

/* this is the CsvGroupByAggregateQueryProcessor class used for evaluating queries with 
 * aggregate functions and group by clause*/
public class CsvGroupByAggregateQueryProcessor implements QueryProcessingEngine {

	public HashMap getResultSet(QueryParameter queryParameter) {
		
		//initialize BufferedReader
		
		
		
		//read the first line which contains the header
		
		
		
		//read the next line which contains the first row of data
					
		
		
		//populate the header Map object from the header array
			
		
		
		//populate the dataType map object from the first line
		
		
		
		//reset the buffered reader so that it can start reading from the first line
		
		
		
		//skip the first line as it is already read earlier
		
		
		
		//read one line at a time from the CSV file
				
		
		
		//apply the conditions mentioned in the where clause on the row data

		/*check for multiple conditions in where clause
		 * for eg: where salary>20000 and city=Bangalore
		 * for eg: where salary>20000 or city=Bangalore and dept!=Sales*/
						
		
		/*evaluate multiple conditions*/
		
		
		
		/*check if the row is selected*/
		
		
		
		// checking if the group by column value is there in the map
		
		
		
		// Evaluate the aggregate functions with group by clause
		
		
		
		//return dataSet
		return null;
	}
	
	
	
	
	
}
