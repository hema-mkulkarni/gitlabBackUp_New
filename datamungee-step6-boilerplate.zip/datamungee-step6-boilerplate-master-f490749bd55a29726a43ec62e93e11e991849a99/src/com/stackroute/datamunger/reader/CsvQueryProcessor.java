package com.stackroute.datamunger.reader;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import com.stackroute.datamunger.query.DataSet;
import com.stackroute.datamunger.query.DataTypeDefinitions;
import com.stackroute.datamunger.query.Filter;
import com.stackroute.datamunger.query.Header;
import com.stackroute.datamunger.query.Row;
import com.stackroute.datamunger.query.RowDataTypeDefinitions;
import com.stackroute.datamunger.query.parser.QueryParameter;
import com.stackroute.datamunger.query.parser.Restriction;


//this class will read from CSV file and process and return the resultSet
public class CsvQueryProcessor implements QueryProcessingEngine {

	public DataSet getResultSet(QueryParameter queryParameter) {
		
		//initialize BufferedReader
		
		
		
		//read the first line which contains the header
			
		
		
		//read the next line which contains the first row of data
		
		
		
		//populate the header Map object from the header array
		
		
		
		//populate the dataType map object from the first line
		
		
		
		//reset the buffered reader so that it can start reading from the first line
					
		
		
		//skip the first line as it is already read earlier
		
		
		
		//read one line at a time from the CSV file
		
		
		
		//apply the conditions mentioned in the where clause on the row data
		
								
		//check if the row read satisfies all the conditions
				
		
		
		//check if all columns are required
		
		
		
		//get the selected columns to be selected and push it to row object
		
		
		
		//add the row object to the dataset object
		
		
		//return dataset
		return null;
	}
	
	
	
	
	
}
