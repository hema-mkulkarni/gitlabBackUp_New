package com.stackroute.datamunger.query;

import java.util.HashMap;

//contains the row object as ColumnName/Value 
public class Row extends HashMap<String, String>{
	
}
