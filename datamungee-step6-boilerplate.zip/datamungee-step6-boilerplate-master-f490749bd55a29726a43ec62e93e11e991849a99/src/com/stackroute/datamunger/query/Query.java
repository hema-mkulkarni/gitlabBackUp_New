package com.stackroute.datamunger.query;

import java.util.HashMap;

import com.stackroute.datamunger.query.parser.QueryParameter;
import com.stackroute.datamunger.query.parser.QueryParser;
import com.stackroute.datamunger.reader.CsvAggregateQueryProcessor;
import com.stackroute.datamunger.reader.CsvGroupByAggregateQueryProcessor;
import com.stackroute.datamunger.reader.CsvGroupByQueryProcessor;
import com.stackroute.datamunger.reader.CsvQueryProcessor;
import com.stackroute.datamunger.reader.QueryProcessingEngine;

public class Query {

	public HashMap executeQuery(String queryString) {

		
		// checking type of Query
		
		
		
		// queries without aggregate functions, order by clause or group by clause
		
		
		
		//queries with aggregate functions
		
		
		
		//Queries with group by clause
		
		
		//Queries with group by and aggregate functions


		return null;
	}

}
