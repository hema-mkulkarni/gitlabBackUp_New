package com.stackroute.datamunger;

import java.util.Scanner;

import com.stackroute.datamunger.query.Query;
import com.stackroute.datamunger.writer.JsonWriter;


public class DataMunger {
	
	public static void main(String[] args){
		
		//read the query from the user
		
		
		//instantiate Query class
		
		
		//call executeQuery() method to get the resultSet and write to JSON file
		

	}
}
