package com.stackroute.datamunger.reader;

import java.util.HashMap;

import com.stackroute.datamunger.query.parser.QueryParameter;


/* this is the CsvAggregateQueryProcessor class used for evaluating queries with 
 * aggregate functions without group by clause*/
public class CsvAggregateQueryProcessor implements QueryProcessingEngine {

	public HashMap getResultSet(QueryParameter queryParameter) {
		
		
		//initialize BufferedReader
		
		//read the first line which contains the header
			
		//read the next line which contains the first row of data
		
		//populate the header Map object from the header array
			
		//populate the dataType map object from the first line
		
		//reset the buffered reader so that it can start reading from the first line
		
		//skip the first line as it is already read earlier
			
		
		//read one line at a time from the CSV file
				
		
		//apply the conditions mentioned in the where clause on the row data
							
		/*check for multiple conditions in where clause 
		 * for eg: where salary>20000 and city=Bangalore
		 * for eg: where salary>20000 or city=Bangalore and dept!=Sales*/
						
		/*if the row is selected after evaluating all conditions*/						
		
		/* evaluate all the aggregate functions one by one*/
					
					
		
		//return dataSet
		return null;
	}
	
	
	
	
	
}
