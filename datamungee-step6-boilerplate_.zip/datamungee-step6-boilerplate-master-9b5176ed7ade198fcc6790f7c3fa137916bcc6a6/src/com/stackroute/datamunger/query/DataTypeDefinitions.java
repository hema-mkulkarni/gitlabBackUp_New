package com.stackroute.datamunger.query;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//this class contains methods to find the column data types
public class DataTypeDefinitions {

	public static Object getDataType(String input) {
		
		//check for empty object
		
		
		// checking for Integer
		
		
		// checking for floating point numbers
		
		
		// checking for date format dd/mm/yyyy
		
		
		// checking for date format mm/dd/yyyy
		
		
		// checking for date format dd-mon-yy
		
		
		// checking for date format dd-mon-yyyy
		
		
		// checking for date format dd-month-yy
		
		
		// checking for date format dd-month-yyyy
		
		return null;
	}
	
	
}
