package com.stackroute.datamunger.query.parser;

public class Restriction {
	
	

}
