package com.stackroute.datamunger.query.parser;

import java.util.List;
import java.util.Map;

//this class contains the parameters and accessor/mutator methods of QueryParameter
public class QueryParameter {

	
}
