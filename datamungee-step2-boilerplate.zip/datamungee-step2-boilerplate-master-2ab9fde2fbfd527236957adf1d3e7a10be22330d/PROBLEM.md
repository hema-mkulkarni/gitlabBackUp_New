### Problem Statement

In our first assignment we extracted different parts of the query and just displayed.
In this assignment we should store the query parameters/parts. We should think where to store these parameters.
To do this we have to create a separate class with properties and methods.
The class name should be meaningful like QueryParameter. In this QueryParameter class we need to add properties so that we store various parts of the query string which we splitted in our earlier assignment.