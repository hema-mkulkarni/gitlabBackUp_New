package com.stackroute.datamunger.query.parser;

/*
 * This class is used for storing name of field, condition and value for 
 * each conditions
 * */
public class Restriction {
	
	public String getPropertyName() {
		return null;
	}
	public String getPropertyValue() {
		return null;
	}
	public String getCondition() {
		return null;
	}

}
