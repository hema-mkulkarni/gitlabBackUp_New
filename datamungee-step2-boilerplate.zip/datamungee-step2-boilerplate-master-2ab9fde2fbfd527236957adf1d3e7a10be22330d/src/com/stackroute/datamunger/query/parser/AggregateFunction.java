package com.stackroute.datamunger.query.parser;

/* This class is used for storing name of field, aggregate function for 
 * each aggregate function
 * */
public class AggregateFunction {
	
	public String getField() {
		return null;
	}
	
	public String getFunction() {
		return null;
	}
}
