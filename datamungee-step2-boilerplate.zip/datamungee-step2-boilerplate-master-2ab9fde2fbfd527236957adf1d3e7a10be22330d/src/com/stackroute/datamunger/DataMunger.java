package com.stackroute.datamunger;

public class DataMunger {

	public static void main(String[] args) {

		
		//read the query from the user
		
		
		//create an object of QueryParser class
		
		
		/*
		 * call parseQuery() method of the class by passing the query string which will
		 * return object of QueryParameter
		 */
		
		

	}

	

}
