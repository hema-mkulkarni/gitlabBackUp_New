package com.stackroute.datamunger.query;

import java.util.HashMap;
import java.util.List;

public class GroupDataSet extends HashMap<String,List<Row>> {

}