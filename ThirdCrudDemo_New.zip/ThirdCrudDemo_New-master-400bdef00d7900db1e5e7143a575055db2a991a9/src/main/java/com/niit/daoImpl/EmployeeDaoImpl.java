package com.niit.daoImpl;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.dao.EmployeeDao;
import com.niit.model.Employee;

@Repository(value = "employeeDAO")
@Transactional
public class EmployeeDaoImpl implements EmployeeDao {
	@Autowired
	SessionFactory sessionFactory;

	public EmployeeDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Employee> getAllEmployees() {
		Session session = null;
		session = sessionFactory.openSession();
		System.out.println("In getAllEmployees()");
		Query query = session.createQuery("from Employee order by empName");
		List<Employee> empList = query.list();
		session.close();
		return empList;
	}

	@Override
	public boolean addEmployee(Employee employee) {
		Session session = null;
		session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		return true;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		Session session = null;
		session = sessionFactory.openSession();
		session.beginTransaction();
		session.update(employee);
		session.getTransaction().commit();
		session.close();
		return true;
	}

	@Override
	public boolean deleteEmployee(Employee employee) {

		try {
			Session session = sessionFactory.openSession();
			session.beginTransaction();
			session.delete(employee);
			session.getTransaction().commit();
			session.close();
			return true;
		} catch (Exception exception) {
			return false;
		}
	}

	@Override
	public boolean deleteEmpById(int empId) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Object o = session.load(Employee.class, empId);
		session.delete(o);
		session.getTransaction().commit();
		return false;
	}

	@Override
	public List<Employee> getEmployeeById(int empId) {
		List<Employee> employees = sessionFactory.getCurrentSession()
				.createQuery("from Employee emp where emp.empId=" + empId).list();
		/*if (employees.size() > 0) {
			return employees.get(0);
		}*/
		return employees;
	}

	@Override
	public boolean updateEmployee(int empId, Employee employee) {
		/*Employee newEmployee = getEmployeeById(empId);
		newEmployee.setEmailId(employee.getEmailId());
		newEmployee.setEmpName(employee.getEmpName());

		Session session = null;
		session = sessionFactory.openSession();
		session.beginTransaction();
		session.saveOrUpdate(newEmployee);
		session.getTransaction().commit();*/
		return true;
	}

	/*
	 * @Override public Employee getEmployeeById(int empId) { Session session =
	 * null; session = sessionFactory.openSession(); System.out.println(
	 * "In getAllEmployees()"); Query query = session.createQuery(
	 * "from Employee order by empName where empid=empid"); Employee emprec =
	 * query.get session.close(); return emprec; }
	 */
}