package com.niit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.niit.dao.EmployeeDao;
import com.niit.model.Employee;

@RestController
public class EmployeeRestController {
	@Autowired
	EmployeeDao employeeDao;

	@GetMapping("/employees")
	public List getEmployees() {
		return employeeDao.getAllEmployees();
	}

	@GetMapping("/employees/{id}")
	public ResponseEntity getEmployee(@PathVariable("id") int id) {

		List<Employee> employee = employeeDao.getEmployeeById(id);
		if (employee == null) {
			return new ResponseEntity("No employee found for ID " + id, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(employee, HttpStatus.OK);
	}
	@GetMapping("/getEmployee{empId}")
	public ResponseEntity<List<Employee>>  getEmployeeById(@RequestParam("empId")int empId) {
		
		System.out.println("By Id Page " + empId);
		List<Employee> employees=employeeDao.getEmployeeById(empId);
		//model.addAttribute("employees",employees);
		return new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}

	@GetMapping("/")
	public ResponseEntity<List<Employee>> getAllEmployeees() {

		List<Employee> employees = employeeDao.getAllEmployees();
		// model.addAttribute("employees",employees);
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@GetMapping("/emp")
	public ResponseEntity<List<Employee>> getAllEmployees() {

		List<Employee> employees = employeeDao.getAllEmployees();

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PostMapping("/addEmployee")
	public ResponseEntity<List<Employee>> addEmployee(RequestEntity<Employee> requestEntity) {

		employeeDao.addEmployee((Employee) requestEntity.getBody());
		List<Employee> employees = employeeDao.getAllEmployees();
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PostMapping(value = "/employees")
	public ResponseEntity createCustomer(@RequestBody Employee employee) {
		employeeDao.addEmployee(employee);
		return new ResponseEntity(employee, HttpStatus.OK);
	}

	@DeleteMapping(value = "/delete{empId}")
	public ResponseEntity<List<Employee>> deleteEmployee(@RequestParam("empId") int empId) {
		System.out.println("Delete By Id Page " + empId);
		employeeDao.deleteEmpById(empId);
		List<Employee> employees = employeeDao.getAllEmployees();
		// model.addAttribute("employees",employees);
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	@PutMapping(value = "/update{empId}")
	public ResponseEntity<List<Employee>> updateEmployee(@RequestParam("empId") int empId,
			RequestEntity<Employee> employee) {

		System.out.println("Update By Id Page " + empId);
		employeeDao.updateEmployee(empId, (Employee) employee.getBody());
		List<Employee> employees = employeeDao.getAllEmployees();

		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

}