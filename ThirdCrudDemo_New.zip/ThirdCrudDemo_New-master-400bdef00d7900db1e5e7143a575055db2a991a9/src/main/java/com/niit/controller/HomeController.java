package com.niit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.niit.dao.EmployeeDao;
import com.niit.model.Employee;

@Controller
public class HomeController {

	@Autowired
	EmployeeDao employeeDAO;

	@Autowired
	Employee employee;

	@RequestMapping("/")
	public String getEmployees(Model model) {
		List<Employee> employees = employeeDAO.getAllEmployees();
		model.addAttribute("employees", employees);
		return "index";
	}

	@PostMapping("/saveMessage")
	public String saveEmployee(@RequestParam("empName") String empName, @RequestParam("emailId") String emailId) {

		employee.setEmpName(empName);
		employee.setEmailId(emailId);
		employeeDAO.addEmployee(employee);
		return "redirect:/";
	}
}