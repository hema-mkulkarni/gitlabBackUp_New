package com.niit.dao;

import java.util.List;

import com.niit.model.Employee;

public interface EmployeeDao {
	List<Employee> getAllEmployees();

	boolean addEmployee(Employee employee);

	boolean updateEmployee(Employee employee);

	boolean deleteEmployee(Employee employee);

	boolean deleteEmpById(int empId);

	List<Employee> getEmployeeById(int empId);

	boolean updateEmployee(int empId, Employee employee);
}