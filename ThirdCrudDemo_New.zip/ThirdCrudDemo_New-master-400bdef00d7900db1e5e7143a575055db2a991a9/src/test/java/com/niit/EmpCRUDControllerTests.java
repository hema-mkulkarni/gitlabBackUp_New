package com.niit;

import java.util.Arrays;
import static org.mockito.Mockito.*;
import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.niit.config.ApplicationContextConfig;
import com.niit.controller.EmployeeRestController;
import com.niit.controller.HomeController;
import com.niit.dao.EmployeeDao;
import com.niit.model.Employee;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ApplicationContextConfig.class })
@WebAppConfiguration
public class EmpCRUDControllerTests {
	private MockMvc mockMvc;
	@Mock
	Employee employee;
	@Mock
	EmployeeDao employeeDao;
	@InjectMocks
	EmployeeRestController employeeRestController = new EmployeeRestController();
	HomeController homeController = new HomeController();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(employeeRestController).build();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void getAllEmployees() throws Exception {
		/*
		 * Employee employee1 = new Employee();
		 * employee1.setEmpName("HemaKulkarni");
		 * employee1.setEmailId("hvkulkarni@gmail.com");
		 * 
		 * Employee employee2 = new Employee(); employee2.setEmpName(
		 * "Poorva Kulkarni"); employee2.setEmailId("pkulkarni@gmail.com");
		 */
		when(employeeDao.getAllEmployees()).thenReturn(
				Arrays.asList(new Employee("Sam", "Sam@gmail.com"), new Employee("John", "John@gmail.com")));
		ObjectMapper mapper = new ObjectMapper();
		mockMvc.perform(get("/")).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$[0].empName", is("Sam")));
	}

	@Test
	public void getEmployeeById() throws Exception {
		when(employeeDao.getAllEmployees()).thenReturn(
				Arrays.asList(new Employee("Sam", "Sam@gmail.com"), new Employee("John", "John@gmail.com")));

		mockMvc.perform(get("/getEmployee").param("empId", "2")).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andExpect(jsonPath("$[0].empName", is("Sam")));
	}
	@Test
	public void addEmployee() throws Exception{
		Employee employee = new Employee();
		employee.setEmailId("Prajakta@niit.com");
		employee.setEmpName("Praju");
		when(employeeDao.addEmployee(employee)).thenReturn(true);
		mockMvc.perform(post("/addEmployee")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(employee)))
				.andExpect(status().isOk());
		
	}
	
	@Test
	public void updateEmployee() throws Exception{
	
		Employee employee1 = new Employee();
		employee1.setEmailId("Kirti@niit.com");
		employee1.setEmpName("Kirti Patil");
		when(employeeDao.getEmployeeById(1)).thenReturn(Arrays.asList(employee1));
		when(employeeDao.updateEmployee(1, employee1)).thenReturn(true);
		
		mockMvc.perform(put("/update")
				.param("empId", "1")
				.contentType(MediaType.APPLICATION_JSON)
				.content(new ObjectMapper().writeValueAsString(employee1)))
		.andExpect(status().isOk());
	}
	
	@Test
	public void deleteEmployee() throws Exception{
		Employee employee1 = new Employee();
		employee1.setEmailId("Kirti@niit.com");
		employee1.setEmpName("Kirti Patil");
		
		Employee employee2 = new Employee();
		employee2.setEmailId("anjali@niit.com");
		employee2.setEmpName("Anjali");
		
		when(employeeDao.getEmployeeById(1)).thenReturn(Arrays.asList(employee1));
		when(employeeDao.deleteEmpById(employee1.getEmpId())).thenReturn(true);
		
		//when(empDAO.deleteEmployee(1)).thenReturn(true);
		mockMvc.perform(delete("/delete")
				.param("empId", "1"))
				.andExpect(status().isOk());
	}


}