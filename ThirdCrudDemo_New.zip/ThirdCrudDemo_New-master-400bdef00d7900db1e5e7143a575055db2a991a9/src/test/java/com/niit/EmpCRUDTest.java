package com.niit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.niit.config.ApplicationContextConfig;
import com.niit.dao.EmployeeDao;
import com.niit.model.Employee;

@RunWith(SpringRunner.class)
@WebAppConfiguration
@Transactional
@ContextConfiguration(classes = { ApplicationContextConfig.class })

public class EmpCRUDTest {
	@Autowired
	Employee employee;
	@Autowired
	EmployeeDao employeeDao;
	@Autowired
	SessionFactory sessionFactory;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void addEmptest() {
		Employee employee = new Employee();
		employee.setEmpName("PunamJ");
		employee.setEmailId("Punam.j@niit.com");
		assertEquals("PunamJ", employee.getEmpName());
		assertEquals("Punam.j@niit.com", employee.getEmailId());
		// fail("Not yet implemented");
	}

	@Test
	public void ListEmployeestest() {
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList = employeeDao.getAllEmployees();
		// assertEquals(employeeList.size()>0,employeeList.size(),"size <0");
		// assertEquals(employeeList.size() > 0);
	}

	@Test
	public void getEmployeestest() {
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList = employeeDao.getAllEmployees();
		assertNotNull("Retrieval of employees failed.", employeeList);
	}
}