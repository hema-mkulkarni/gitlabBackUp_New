package com.stackroute.datamunger.query;

//this class contains methods to evaluate expressions
public class Filter {
	
	//method to evaluate expression for eg: salary>20000
	
	
	
	
	
	
	//method containing implementation of equalTo operator
	
	
	
	
	
	
	
	
	//method containing implementation of greaterThan operator
	
	
	
	
	
	
	
	//method containing implementation of greaterThanOrEqualTo operator
	
	
	
	
	
	
	//method containing implementation of lessThan operator
	  
	
	
	
	
	//method containing implementation of lessThanOrEqualTo operator
	
}
