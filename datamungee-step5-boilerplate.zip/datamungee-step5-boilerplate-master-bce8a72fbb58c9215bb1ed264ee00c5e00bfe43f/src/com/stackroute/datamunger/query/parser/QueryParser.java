package com.stackroute.datamunger.query.parser;

import java.util.ArrayList;
import java.util.List;

public class QueryParser {

	
	//this method will parse the queryString and will return the object of QueryParameter
	//class
	public QueryParameter parseQuery(String queryString) {
	
		return null;
	}
	
	
}
