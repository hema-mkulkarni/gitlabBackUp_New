package com.stackroute.datamunger.query.parser;

import java.util.List;
import java.util.Map;

//this class contains the parameters and accessor/mutator methods of QueryParameter
public class QueryParameter {

	public Object getFile() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> getFields() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Restriction> getRestrictions() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> getOrderByFields() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getBaseQuery() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> getGroupByFields() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getQUERY_TYPE() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<AggregateFunction> getAggregateFunctions() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getLogicalOperators() {
		// TODO Auto-generated method stub
		return null;
	}

		

	
}
