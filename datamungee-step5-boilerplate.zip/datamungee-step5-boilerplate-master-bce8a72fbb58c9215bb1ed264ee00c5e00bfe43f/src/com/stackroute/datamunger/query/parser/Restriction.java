package com.stackroute.datamunger.query.parser;


public class Restriction {

	public String getPropertyName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getCondition() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getPropertyValue() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
