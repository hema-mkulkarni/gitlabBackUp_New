package com.stackroute.datamunger.query;

import java.util.HashMap;
import java.util.LinkedHashMap;

//this class will be acting as the DataSet containing multiple rows
public class DataSet extends LinkedHashMap<Long, Row> {
	
}
