package com.stackroute.datamunger.query;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//this class contains methods to find the column data types
public class DataTypeDefinitions {

	//method stub
	public static Object getDataType(String input) {
	
		return null;
	}
	

	
}
