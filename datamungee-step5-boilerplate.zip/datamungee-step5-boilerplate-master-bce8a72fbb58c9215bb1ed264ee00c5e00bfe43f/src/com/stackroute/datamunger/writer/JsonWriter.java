package com.stackroute.datamunger.writer;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class JsonWriter {
	//this method will write the resultSet into a JSON file
	public boolean writeToJson(Map resultSet) {
		
		//Gson is a third party library to convert Java object to JSON
		Gson gson=new GsonBuilder().setPrettyPrinting().create();
		String result=gson.toJson(resultSet);
		
	
			//write result to rerouces/result.json file using BufferedWriter
		
			//return true if file writing is successful
			
			//return false if file writing is failed
			
			//close BufferedWriter object
		
		return false;
		}
			
					
}


